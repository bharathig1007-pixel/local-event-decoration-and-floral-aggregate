# Eventify – Local Event Decoration & Floral Aggregator

Hackathon project based on the problem statement:
**Local Event Decoration & Floral Aggregator**

## Technology
- Java 17+
- Spring Boot
- Spring Web / REST APIs
- Spring Data JPA / Hibernate
- MySQL
- React + Vite
- Git / GitHub

## Main flow
React form → Spring Boot REST API → MySQL database search → matching decorator cards → booking/contact option.

## Features
- Search decorators by event type, location, date, budget and service
- Matching decorator cards with price, portfolio, rating and availability
- Booking request form
- Backend validation
- Meaningful HTTP responses
- Loading, success, validation and error states
- MySQL persistence using JPA/Hibernate
- CORS configured for React development server

## Project structure
```text
eventify-local-decorator-aggregator/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/eventify/
│       │   ├── EventifyApplication.java
│       │   ├── config/CorsConfig.java
│       │   ├── controller/DecoratorController.java
│       │   ├── controller/BookingController.java
│       │   ├── dto/DecoratorSearchRequest.java
│       │   ├── dto/BookingRequest.java
│       │   ├── entity/Decorator.java
│       │   ├── entity/Booking.java
│       │   ├── repository/DecoratorRepository.java
│       │   ├── repository/BookingRepository.java
│       │   └── service/DecoratorService.java
│       └── resources/
│           ├── application.properties
│           └── schema.sql
├── frontend/
│   ├── package.json
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       └── styles.css
└── .gitignore
```

## 1. Create MySQL database
```sql
CREATE DATABASE eventify_db;
```

Then update `backend/src/main/resources/application.properties` if your MySQL username/password is different.

Environment variables are also supported:
- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`

## 2. Run backend
Requirements: Java 17+ and Maven.

```bash
cd backend
mvn spring-boot:run
```

Backend:
`http://localhost:8080`

## 3. Run frontend
Requirements: Node.js 18+.

```bash
cd frontend
npm install
npm run dev
```

Frontend:
`http://localhost:5173`

## Demo flow
1. Open the React application.
2. Enter event type, location, date, budget and service.
3. Click **Find Decorators**.
4. React calls `POST /api/decorators/search`.
5. Spring Boot searches MySQL using JPA/Hibernate.
6. Matching decorators appear as cards.
7. Click **Book Now** and submit the booking.
8. Booking is stored in MySQL.

## REST APIs

### Search
`POST /api/decorators/search`

Example:
```json
{
  "eventType": "Wedding",
  "location": "Tirupati",
  "date": "2026-11-15",
  "budget": 30000,
  "service": "Floral Decoration"
}
```

### Get all decorators
`GET /api/decorators`

### Get one decorator
`GET /api/decorators/{id}`

### Create booking
`POST /api/bookings`

## Suggested Git commits
```text
feat: create Spring Boot backend
feat: add decorator search REST API
feat: add MySQL JPA persistence
feat: create React search UI
feat: add decorator result cards
feat: add booking flow
docs: add README and setup instructions
```
