package com.eventify.repository;

import com.eventify.entity.Decorator;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DecoratorRepository extends JpaRepository<Decorator, Long> {
    List<Decorator> findByLocationIgnoreCaseAndEventTypeIgnoreCaseAndServiceIgnoreCaseAndPriceLessThanEqualAndAvailableTrue(
            String location, String eventType, String service, Double price);
}
