package com.eventify.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public class DecoratorSearchRequest {
    @NotBlank(message = "Event type is required")
    private String eventType;

    @NotBlank(message = "Location is required")
    private String location;

    @NotNull(message = "Event date is required")
    @FutureOrPresent(message = "Event date cannot be in the past")
    private LocalDate date;

    @NotNull(message = "Budget is required")
    @Positive(message = "Budget must be greater than zero")
    private Double budget;

    @NotBlank(message = "Service is required")
    private String service;

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public Double getBudget() { return budget; }
    public void setBudget(Double budget) { this.budget = budget; }

    public String getService() { return service; }
    public void setService(String service) { this.service = service; }
}
