package com.eventify.controller;

import com.eventify.dto.BookingRequest;
import com.eventify.entity.Booking;
import com.eventify.entity.Decorator;
import com.eventify.repository.BookingRepository;
import com.eventify.repository.DecoratorRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    private final BookingRepository bookingRepository;
    private final DecoratorRepository decoratorRepository;

    public BookingController(BookingRepository bookingRepository, DecoratorRepository decoratorRepository) {
        this.bookingRepository = bookingRepository;
        this.decoratorRepository = decoratorRepository;
    }

    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody BookingRequest request) {
        Decorator decorator = decoratorRepository.findById(request.getDecoratorId()).orElse(null);

        if (decorator == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Decorator not found"));
        }

        if (!decorator.isAvailable()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Decorator is currently unavailable"));
        }

        Booking booking = new Booking();
        booking.setDecorator(decorator);
        booking.setCustomerName(request.getCustomerName().trim());
        booking.setPhone(request.getPhone());
        booking.setEventDate(request.getEventDate());
        booking.setStatus("PENDING");

        Booking saved = bookingRepository.save(booking);

        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "message", "Booking request submitted successfully",
                "bookingId", saved.getId()
        ));
    }
}
