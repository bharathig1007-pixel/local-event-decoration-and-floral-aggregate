package com.eventify.controller;

import com.eventify.dto.DecoratorSearchRequest;
import com.eventify.entity.Decorator;
import com.eventify.repository.DecoratorRepository;
import com.eventify.service.DecoratorService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/decorators")
public class DecoratorController {
    private final DecoratorRepository repository;
    private final DecoratorService service;

    public DecoratorController(DecoratorRepository repository, DecoratorService service) {
        this.repository = repository;
        this.service = service;
    }

    @GetMapping
    public List<Decorator> getAll() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Decorator> getById(@PathVariable Long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/search")
    public ResponseEntity<List<Decorator>> search(@Valid @RequestBody DecoratorSearchRequest request) {
        return ResponseEntity.ok(service.search(request));
    }
}
