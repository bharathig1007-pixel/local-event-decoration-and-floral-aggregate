package com.eventify.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;

public class BookingRequest {
    @NotNull(message = "Decorator id is required")
    private Long decoratorId;

    @NotBlank(message = "Customer name is required")
    private String customerName;

    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must contain 10 digits")
    private String phone;

    @NotNull(message = "Event date is required")
    @FutureOrPresent(message = "Event date cannot be in the past")
    private LocalDate eventDate;

    public Long getDecoratorId() { return decoratorId; }
    public void setDecoratorId(Long decoratorId) { this.decoratorId = decoratorId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public LocalDate getEventDate() { return eventDate; }
    public void setEventDate(LocalDate eventDate) { this.eventDate = eventDate; }
}
