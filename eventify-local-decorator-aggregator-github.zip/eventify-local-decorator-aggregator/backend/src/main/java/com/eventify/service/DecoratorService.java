package com.eventify.service;

import com.eventify.dto.DecoratorSearchRequest;
import com.eventify.entity.Decorator;
import com.eventify.repository.DecoratorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DecoratorService {
    private final DecoratorRepository repository;

    public DecoratorService(DecoratorRepository repository) {
        this.repository = repository;
    }

    public List<Decorator> search(DecoratorSearchRequest request) {
        return repository
                .findByLocationIgnoreCaseAndEventTypeIgnoreCaseAndServiceIgnoreCaseAndPriceLessThanEqualAndAvailableTrue(
                        request.getLocation().trim(),
                        request.getEventType().trim(),
                        request.getService().trim(),
                        request.getBudget());
    }
}
