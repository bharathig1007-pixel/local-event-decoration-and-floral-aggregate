INSERT IGNORE INTO decorators
(id, name, location, event_type, service, price, rating, available, phone, portfolio_url, description)
VALUES
(1, 'Royal Events & Flowers', 'Tirupati', 'Wedding', 'Floral Decoration', 28000, 4.7, true, '9876543210', 'https://example.com/royal-events', 'Wedding stage, floral and venue decoration.'),
(2, 'Sri Lakshmi Decorations', 'Tirupati', 'Wedding', 'Stage Decoration', 24000, 4.5, true, '9876543211', 'https://example.com/sri-lakshmi', 'Traditional and modern wedding stage decoration.'),
(3, 'Star Birthday Decor', 'Tirupati', 'Birthday', 'Balloon Decoration', 12000, 4.6, true, '9876543212', 'https://example.com/star-birthday', 'Birthday themes, balloons and photo backdrops.'),
(4, 'Green Petals Florals', 'Chittoor', 'Engagement', 'Floral Decoration', 18000, 4.8, true, '9876543213', 'https://example.com/green-petals', 'Fresh flower arrangements and engagement decor.'),
(5, 'Dream Venue Decor', 'Chittoor', 'Reception', 'Full Venue Decoration', 42000, 4.4, false, '9876543214', 'https://example.com/dream-venue', 'Complete reception venue decoration packages.');
