import React, { useState } from "react";

const API = "http://localhost:8080/api";

const initialForm = {
  eventType: "Wedding",
  location: "Tirupati",
  date: "",
  budget: 30000,
  service: "Floral Decoration",
};

export default function App() {
  const [form, setForm] = useState(initialForm);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [booking, setBooking] = useState({ customerName: "", phone: "", eventDate: "" });

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function searchDecorators(e) {
    e.preventDefault();
    setError("");
    setMessage("");
    setResults([]);

    if (!form.date) {
      setError("Please select an event date.");
      return;
    }
    if (Number(form.budget) <= 0) {
      setError("Budget must be greater than ₹0.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API}/decorators/search`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, budget: Number(form.budget) }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || "Unable to search decorators.");
      }

      const data = await response.json();
      setResults(data);
      setMessage(`${data.length} matching decorator${data.length === 1 ? "" : "s"} found.`);
    } catch (err) {
      setError(err.message || "Unable to connect to the backend.");
    } finally {
      setLoading(false);
    }
  }

  async function submitBooking(e) {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      const response = await fetch(`${API}/bookings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          decoratorId: selected.id,
          ...booking,
        }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message || "Booking failed.");

      setMessage(`Booking submitted successfully. Booking ID: ${data.bookingId}`);
      setSelected(null);
      setBooking({ customerName: "", phone: "", eventDate: "" });
    } catch (err) {
      setError(err.message || "Booking failed.");
    }
  }

  return (
    <div className="app">
      <header className="hero">
        <nav>
          <div className="brand">🌸 Eventify</div>
          <span>Local Event Decoration & Floral Aggregator</span>
        </nav>
        <div className="hero-content">
          <div>
            <p className="eyebrow">FIND • COMPARE • BOOK</p>
            <h1>Find the perfect decorator for your special day.</h1>
            <p className="hero-text">
              Tell us your event requirements and discover local decorators that match
              your location, service and budget.
            </p>
          </div>
          <div className="hero-card">✨ Trusted local event services</div>
        </div>
      </header>

      <main>
        <section className="search-panel">
          <div className="section-title">
            <span>01</span>
            <div>
              <h2>Find Your Decorator</h2>
              <p>Enter your event requirements.</p>
            </div>
          </div>

          <form onSubmit={searchDecorators} className="search-form">
            <label>
              Event Type
              <select name="eventType" value={form.eventType} onChange={update}>
                <option>Wedding</option>
                <option>Birthday</option>
                <option>Engagement</option>
                <option>Reception</option>
              </select>
            </label>

            <label>
              Location
              <input name="location" value={form.location} onChange={update} placeholder="e.g. Tirupati" />
            </label>

            <label>
              Event Date
              <input type="date" name="date" value={form.date} onChange={update} />
            </label>

            <label>
              Budget (₹)
              <input type="number" name="budget" value={form.budget} onChange={update} min="1" />
            </label>

            <label>
              Required Service
              <select name="service" value={form.service} onChange={update}>
                <option>Floral Decoration</option>
                <option>Stage Decoration</option>
                <option>Balloon Decoration</option>
                <option>Full Venue Decoration</option>
              </select>
            </label>

            <button className="primary" disabled={loading}>
              {loading ? "Searching..." : "Find Decorators →"}
            </button>
          </form>

          {error && <div className="alert error">⚠️ {error}</div>}
          {message && <div className="alert success">✅ {message}</div>}
        </section>

        <section className="results">
          <div className="section-title">
            <span>02</span>
            <div>
              <h2>Matching Decorators</h2>
              <p>Based on your selected requirements.</p>
            </div>
          </div>

          {results.length === 0 && !loading ? (
            <div className="empty">
              <div>🔎</div>
              <h3>No results yet</h3>
              <p>Fill the form above and click “Find Decorators”.</p>
            </div>
          ) : (
            <div className="grid">
              {results.map((decorator) => (
                <article className="decorator-card" key={decorator.id}>
                  <div className="card-image">🌸</div>
                  <div className="card-body">
                    <div className="card-top">
                      <span className="pill">{decorator.eventType}</span>
                      <span>⭐ {decorator.rating}</span>
                    </div>
                    <h3>{decorator.name}</h3>
                    <p>{decorator.description}</p>
                    <div className="details">
                      <span>📍 {decorator.location}</span>
                      <span>💐 {decorator.service}</span>
                      <span>💰 ₹{decorator.price.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="availability">
                      {decorator.available ? "● Available" : "● Unavailable"}
                    </div>
                    <div className="actions">
                      <a href={decorator.portfolioUrl} target="_blank" rel="noreferrer">Portfolio</a>
                      <button onClick={() => {
                        setSelected(decorator);
                        setBooking({ ...booking, eventDate: form.date });
                      }}>Book Now</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </main>

      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="close" onClick={() => setSelected(null)}>×</button>
            <p className="eyebrow">BOOKING REQUEST</p>
            <h2>{selected.name}</h2>
            <p>{selected.service} · ₹{selected.price.toLocaleString("en-IN")}</p>
            <form onSubmit={submitBooking}>
              <label>
                Your Name
                <input required value={booking.customerName}
                  onChange={(e) => setBooking({ ...booking, customerName: e.target.value })}
                  placeholder="Enter your name" />
              </label>
              <label>
                Phone
                <input required pattern="[0-9]{10}" value={booking.phone}
                  onChange={(e) => setBooking({ ...booking, phone: e.target.value })}
                  placeholder="10-digit mobile number" />
              </label>
              <label>
                Event Date
                <input type="date" required value={booking.eventDate}
                  onChange={(e) => setBooking({ ...booking, eventDate: e.target.value })} />
              </label>
              <button className="primary" type="submit">Confirm Booking</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
